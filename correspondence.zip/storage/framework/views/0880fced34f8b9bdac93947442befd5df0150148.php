<?php $__env->startSection('title','Data Surat Masuk'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">

    </div>
    <!-- /.content-header -->
    <section class="container">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title font-weight-bold">
                                Data Surat Masuk
                            </h3>
                            <div class="float-right">
                                <a href="<?php echo e(route('inbox.print-pdf')); ?>" class="btn btn-danger btn-sm" target="_blank"><i class="fas fa-print"></i> Cetak PDF</a>
                                <a href="<?php echo e(route('inbox.create')); ?>" class="btn btn-primary btn-sm">Tambah</a>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php if($message = Session::get('create')): ?>
                                <div class="alert alert-info alert-dismissible fade show" role="alert">
                                    <strong>Success!</strong> <?php echo e($message); ?>.
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <?php if($message = Session::get('update')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong>Updated!</strong> <?php echo e($message); ?>.
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <?php if($message = Session::get('delete')): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <strong>Deleted!</strong> <?php echo e($message); ?>.
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <table id="example1" class="table table-bordered table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>NO</th>
                                        <th>TGL SURAT DITERIMA</th>
                                        <th>NO AGENDA SURAT</th>
                                        <th>ALAMAT SURAT</th>
                                        <th>NO. SURAT MASUK</th>
                                        <th>AKSI</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $inboxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($inbox->inbox_received_date)->isoFormat('DD MMMM Y')); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('inbox.show',$inbox->id)); ?>"><?php echo e($inbox->inbox_agenda_number); ?></a>
                                            </td>
                                            <td><?php echo e($inbox->inbox_address); ?></td>
                                            <td><?php echo e($inbox->inbox_number); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('inbox.edit',$inbox->id)); ?>" class="btn btn-sm btn-warning"><i class="fas fa-pen"></i> Edit</a>
                                                <form action="<?php echo e(route('inbox.destroy',$inbox->id)); ?>" class="d-inline" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus data ini ??')"><i class="fas fa-trash"></i> Hapus</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LARAVEL\correspondence\resources\views/inbox/index.blade.php ENDPATH**/ ?>