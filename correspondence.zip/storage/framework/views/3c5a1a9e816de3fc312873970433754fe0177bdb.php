<?php $__env->startSection('title','Edit Data Surat Masuk'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">

    </div>
    <!-- /.content-header -->
    <section class="container">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title font-weight-bold">
                                Edit Data Surat Masuk
                            </h3>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('inbox.update',$inbox->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Tanggal Surat Masuk Diterima</label>
                                            <input type="date" class="form-control" name="inbox_received_date" value="<?php echo e(date('Y-m-d',strtotime($inbox->inbox_received_date))); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Nomor Agenda Surat</label>
                                            <input type="text" class="form-control" name="inbox_agenda_number" value="<?php echo e($inbox->inbox_agenda_number); ?>" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Tanggal Surat</label>
                                            <input type="date" class="form-control" name="inbox_date" value="<?php echo e(date('Y-m-d',strtotime($inbox->inbox_date))); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Alamat Surat</label>
                                            <input type="text" class="form-control" name="inbox_address" value="<?php echo e($inbox->inbox_address); ?>" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Nomor Surat Masuk</label>
                                            <input type="text" class="form-control" name="inbox_number" value="<?php echo e($inbox->inbox_number); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Upload File</label>
                                            <input type="file" name="file" class="form-control p-1">
                                            <iframe src="<?php echo e(asset($inbox->file)); ?>" class="mt-3" style="width: 100%; height: 500px; overflow: hidden; border: none;"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Perihal</label>
                                            <textarea name="subject" class="form-control" rows="4"><?php echo e($inbox->subject); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Keterangan</label>
                                            <textarea name="description" class="form-control" rows="4"><?php echo e($inbox->description); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="float-right">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script>
    $(document).ready(function(){
        $('#lfm').filemanager('file');
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LARAVEL\correspondence\resources\views/inbox/edit.blade.php ENDPATH**/ ?>