<?php $__env->startSection('title','File Manager'); ?>

<?php $__env->startSection('content'); ?>
    <iframe src="<?php echo e(url('/filemanager?type=file')); ?>" style="width: 100%; height: 500px; overflow: hidden; border: none;"></iframe>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LARAVEL\correspondence\resources\views/filemanager.blade.php ENDPATH**/ ?>